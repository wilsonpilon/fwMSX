; MGLOAD2.COM
; Megarom loader for ESE-RAM v1.00 by K.Tsujikawa modified by Jipe
; Supports the mappers ASC8, ASC16 and SCC

LF	equ	0ah
CR	equ	0dh
CTRLZ	equ	01ah
BDOS	equ	00005h
WRSLT	equ	00014h
CALSLT	equ	0001Ch
ENASLT	equ	00024h
FCB	equ	0005ch
DMA	equ	00080h
RAMAD1	equ	0f342h
RAMAD2	equ	0f343h
BUFTOP	equ	08000h
ASCpag0	equ	06000h
ASCpag1	equ	06800h
SCCpag0	equ	05000h
SCCpag1	equ	07000h

	org	00100H
   
Start:
	jp	Main
InfoMess:
	db	CR,"MEGA-ROM loader ver 2.00",CR,LF
	db	"  (c) K.Tsujikawa - Dos2 by (Jipe).",CR,LF,CR,LF,'$'
	db	CR
HlpMes:
	db	"Usage:  MGLOAD2 filename.meg /Sxx",CR,LF,CR,LF
	db	"        (xx : Mega-RAM slot address)",CR,LF,'$'
	db	CR," (^_^)/~",CR,LF,CTRLZ
ImpropMes:
	db	"Improper cartridge !",'$'
FileErrMes:
	db	CR,LF,"File reading error !$"
DoneMes:
	db	"Load complete. Thank you.",'$'
FileDescrip:
	db	0
FIB:
	ds	22,0
Main:
	ld	de,HlpMes
	ld	hl,DMA
	ld	b,(hl)
	inc	b
	dec	b
	jp	z,Exit		; Jump if no parameter
	ld	a,02fh		; A = '/'
SeekOption:
	inc	hl
	cp	(hl)
	jr	z,OptionFND	; Jump if no '/'
	djnz	SeekOption
	jp	Exit

OptionFND:
	inc	hl
	ld	a,(hl)
	and	0dfh
	cp	'S'
	jp	nz,Exit		; Jump if no 'S'

	call	GetNum		; Convert /Sxx option value to FxxxSSPP
	ld	a,e
	ld	(ESEramSlot),a

	ld	bc,24		; Prepare the FCB
	ld	de,FCB+13
	ld	hl,FCB+12
	ld	(hl),b
	ldir			; Initialize the second half with zero

	ld	de,FIB
	ld	hl,00082h
T0235H:
	ld	a,(hl)
	cp	020h
T0238H:	jr	z,T023FH	; Jump to T023FH if A=32
	ld	(de),a
	inc	hl
	inc	de
	jr	T0235H		; Jump to 00235H

T023FH:
	ld	c,043h		; Open File Handle
	ld	de,FIB		; Pointer to the FIB  
	xor	a		; Clear A
	call	BDOS		; 
	ld	hl,00001h
	ld	(FCB+14),hl
	or	a
	ld	de,FileErrMes
	jp	nz,Exit
	ld	a,b
	ld	(FileDescrip),a

	ld	a,(ESEramSlot)
	ld	h,40h
	call	ENASLT		; Select Mega-sram slot on bank 4000h~7fffh

	xor	a
	ld	de,ImpropMes
	ld	bc,ASCpag0
	ld	hl,04000h
	ld	a,(hl)		; Read 04000h address
	cpl			; Reverse bits of A
	ld	(hl),a		; Write reversed value at 04000h address
	cp	(hl)		; Compare A with 04000h address value
	cpl			; Reverse bits of A
	ld	(hl),a		; Restore initial value at 04000h address
	jp	z,Exit		; Jump if the specified slot contains RAM

; -> Must be moved before the RAM test
	xor	a
	ld	(07ffeh),a	; Mode ROM for SCC
	ld	(ASCpag1),a	; 
	ld	(bc),a		; 
	ld	(SCCpag0),a	; 
	ld	(SCCpag1),a	; 
	ld	a,080h
	ld	(bc),a		; Write 080h at 6000h or mode RAM for ASC8

	ld	a,010h
	ld	(07ffeh),a	; Mode RAM at bank 4000h-7FFDh for SCC mapper
	ld	a,(bc)		; Read value at 6000h

	xor	(hl)
	jr	z,ASC8FND	; Jump if Rom mapper is ASC8 type (maybe 8k type)

	ld	a,1		; it's not 8k type
ASC8FND:
	ld	(Page16K),a
	ld	a,(hl)		; Read value at 4000h
	cpl
	ld	(hl),a		; Write reversed value at 4000h
	cp	(hl)
	cpl
	ld	(hl),a
	jr	z,Sram_OK	; Jump if Mega-sram found
	xor	a		;          <- useless?
	ld	(07ffeh),a	; Mode ROM for SCC mapper <- useless?
	ld	(bc),a		; Mode ROM for ASC8 mapper <- useless?
	jp	Exit		; Jump if not Mega-sram

Sram_OK:
	push	af
	ld	a,(bc)		; Read value at 4000h
	cpl
	ld	(hl),a
	ld	a,(bc)
	cp	(hl)
	jr	z,ModeRomOK	; Jump if not Ram mode

	ld	a,1
	ld	(Page16K),a	; Mapper segments size is 16kB
ModeRomOK:
	pop	af
	ld	(hl),a
	xor	a
	ld	(07ffeh),a	; Mode ROM for SCC mapper
	ld	(bc),a		; Mode ROM for ASC8 mapper
	ld	(ESEramPage),a
	inc	a
	ld	(ASCpag1),a	; Select segment 0 on page 6000h~7FFFh if Rom mapper is ASC8
	ld	(SCCpag1),a	; Select segment 0 on page 6000h~7FFFh if Rom mapper is SCC

	ld	a,(RAMAD1)
	ld	h,040h
	call	ENASLT		; Select Main-Ram slot on page 4000h~7fffh

	ld	a,(Page16K)
	or	a
	jp	nz,Loop16k	; Jump if Mapper segments size is 16kB

Loop8k:
	ld	c,048h		; Read From File Handle
	ld	a,(FileDescrip)	; 
	ld	B,A		; File descriptor
	ld	de,08000h	; 
	ld	hl,02000h	; 
	xor	a		; Clear a
	call	BDOS		; Read a block from file

	ld	a,h
	or	l
	ld	de,DoneMes
	jp	z,Exit

	ld	a,h
	cp	020h
	ld	de,FileErrMes
	jp	nz,Exit

	ld	a,(ESEramSlot)
	ld	h,040h
	call	ENASLT		; Select Mega-sram slot on bank 4000h~7fffh

	xor	a
	ld	(07ffeh),a	; Mode ROM for SCC mapper
	ld	(ASCpag0),a	; Mode ROM for ASC8 mapper
	ld	a,(ESEramPage)
	ld	(SCCpag0),a
	or	080h
	ld	(ASCpag0),a
	ld	a,010h
	ld	(07ffeh),a	; Mode RAM at bank 4000h-7FFDh for SCC mapper

	ld	bc,02000h
	ld	de,04000h
	ld	hl,08000h
	ldir

	xor	a
	ld	(07ffeh),a	; Mode ROM for SCC mapper
	ld	(ASCpag0),a	; Mode ROM for ASC8 mapper

	ld	a,(RAMAD1)
	ld	h,40h
	call	ENASLT		; Select Main-Ram slot on bank 4000h~7fffh

	ld	a,(ESEramPage)
	inc	a
	ld	(ESEramPage),a
	dec	a
	and	0fh
	cp	0ah
	jr	c,NotNumber	; Jump if alphabetic character
	add	a,7		; Add 'A'-'0'-10
NotNumber:
	add	a,030h		; Character '0'
	ld	e,a
	ld	c,2		; Console Output
	call	BDOS		; Print page number

	ld	a,(ESEramPage)
	and	0fh
	jp	nz,Loop8k

	ld	e,CR
	ld	c,2		; Console Output
	call	BDOS		; Move cursor to beging line

	ld	e,LF
	ld	c,2		; Console Output
	call	BDOS		; Move cursor to next line

	jp	Loop8k

Loop16k:
	ld	C,048h		; Read From File Handle
	ld	a,(FileDescrip)   
	ld	B,A		; File descriptor  
	ld	de,08000h	; 110080..  ..Ä.  
	ld	hl,04000h	; Number of records to read
	xor	a		; Clear A
	call	BDOS		; Read a block from file

	ld	a,h
	or	l
	ld	de,DoneMes
	jp	z,Exit		; Jump if no byte read.

	ld	a,h
	cp	040h
T0376H:	ld	de,FileErrMes
	jp	nz,Exit		; Jump if bytes read < 4000h.

	ld	bc,04000h
	ld	de,04000h
	ld	hl,08000h
	ldir			; Write a block to the SRAM

	ld	hl,SCCpag1
	ld	a,(ESEramPage)
	or	080h
	ld	e,a
	ld	a,(ESEramSlot)
	call	WRSLT		; Select a page in Mega-sram SCC on bank 8000h~bfffh

	ld	a,(ESEramSlot)
	ld	h,080h
	call	ENASLT		; Select Mega-sram slot on bank 8000h~bfffh

	ld	bc,04000h
	ld	de,08000h
	ld	hl,04000h
	ldir

	ld	a,(RAMAD2)
	ld	h,080h
	call	ENASLT		; Select Main-Ram on bank 8000h~bfffh

	ld	hl,SCCpag1
	ld	e,1
	ld	a,(ESEramSlot)
	call	WRSLT		; Select page 1 in Mega-sram SCC on bank 8000h~bfffh

	ld	a,(ESEramPage)
	inc	a
	ld	(ESEramPage),a
	dec	a
	and	7
	add	a,030h
	ld	e,a
	ld	c,2		; Console Output
	call	BDOS		; Print page number

	ld	a,(ESEramPage)
	and	7
	jp	nz,Loop16k

	ld	e,CR
	ld	c,2		; Console Output
	call	BDOS		; Move cursor to beging line

	ld	e,LF
	ld	c,2		; Console Output
	call	BDOS		; Move cursor to next line

	jp	Loop16k

Exit:
	pop	af
	ld	c,9		; String Output
	call	BDOS		; Print message before exit to DOS

	ld	c,045h		; Close File Handle
	ld	a,(FileDescrip)
	ld	b,a		; File descriptor
	call	BDOS
	rst	0		; Back to the DOS

GetNum:
	ld	de,0
GetL01:
	inc	hl
	ld	a,(hl)
	sub	030h		; sub	'0'
	ret	c
	cp	10
	jr	c,GetR01
	and	0dfh
	sub	7		; sub	'A'-'0'-10
	ret	c
	cp	16
	ccf
	ret	c
GetR01:
	sla	e
	rl	d
	sla	e
	rl	d
	sla	e
	rl	d
	sla	e
	rl	d
	add	a,e
	ld	e,a
	jr	GetL01

ESEramSlot:
	db	0		; Mega-sram Slot
Page16K:
	db	0		; 0 = 8K segments, 1 = 16K
ESEramPage:
	db	0		; 
T0423H:
	NOP			; 
T0424H:
	NOP			; 
