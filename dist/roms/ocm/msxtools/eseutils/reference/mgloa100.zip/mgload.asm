; MGLOAD.COM
; Megarom loader for ESE-RAM v1.00 by K.Tsujikawa
; Support the mappers ASC8, ASC16 and SCC

LF	equ	0ah
CR	equ	0dh
CTRLZ	equ	01ah
BDOS	equ	00005h
WRSLT	equ	00014h
CALSLT	equ	0001Ch
ENASLT	equ	00024h
FCB	equ	0005ch
DMA	equ	00080h
RAMAD1	equ	0f342h
RAMAD2	equ	0f343h
BUFTOP	equ	08000h
ASCbnk0	equ	06000h
ASCbnk1	equ	06800h
SCCbnk0	equ	05000h
SCCbnk1	equ	07000h

	org	00100H
   
Start:           
	jp     Main

InfoMess:
	db	CR,"MEGA-ROM loadr ver 1.00",CR,LF
	db	"  Copyright (c) by K.Tsujikawa.",CR,LF,CR,LF,'$'
	db	CR
HlpMes:
	db	"Usage:  MGLOAD filename.meg /Sxx",CR,LF,CR,LF
	db	"        (xx : Mega-RAM slot address)",CR,LF,'$'
	db	CR," (^_^)/~",CR,LF,CTRLZ
ImpropMes:
	db	"Improper cartridge !",'$'
FileErrMes:
	db	CR,LF,"File reading error !$"
DoneMes:
	db	"Load complete. Thank you.",'$'

Main:
	ld	de,HlpMes
	ld	hl,DMA
	ld	b,(hl)
	inc	b
	dec	b
	jp	z,Exit		; Jump if no parameter

	ld	a,02fh		; A = '/'
SeekOption:
	inc	hl
	cp	(hl)
	jr	z,OptionFND	; Jump if no '/'
	djnz	SeekOption
	jp	Exit

OptionFND:
	inc	hl
	ld	a,(hl)
	and	0dfh
	cp	'S'
	jp	nz,Exit		; Jump if no 'S'

	call	GetNum		; Convert /Sxx option value to FxxxSSPP
	ld	a,e
	ld	(ESEramSlot),a

	ld	bc,24		; Prepare the FCB
	ld	de,FCB+13
	ld	hl,FCB+12
	ld	(hl),b
	ldir			; Initialize the second half with zero

	ld	c,0fh
	ld	de,FCB
	call	BDOS		; Open file

	ld	hl,1
	ld	(FCB+14),hl	; Record size = 1 byte
	or	a
	ld	de,FileErrMes
	jp	nz,Exit

	ld	c,1ah
	ld	de,BUFTOP
	call	BDOS		; Set disk transfer address (buffer start at 8000H)

	ld	a,(ESEramSlot)
	ld	h,40h
	call	ENASLT		; Select Mega-sram slot on bank 4000h~7fffh

	xor	a
	ld	de,ImpropMes
	ld	bc,ASCbnk0
	ld	hl,04000h
	ld	a,(hl)		; Read 04000h address
	cpl			; Reverse bits of A
	ld	(hl),a		; Write reversed value at 04000h address
	cp	(hl)		; Compare A with 04000h address value
	cpl			; Reverse bits of A
	ld	(hl),a		; Restore initial value at 04000h address
	jp	z,Exit		; Jump if the specified slot contains RAM

; -> Must be moved before the RAM test
	xor	a
	ld	(07ffeh),a	; Mode ROM for SCC
	ld	(ASCbnk1),a	; Select page 0 on bank 6000h~7FFFh if Rom mapper is ASC8
	ld	(bc),a		; Write 0 value at 6000h or Mode ROM for ASC8 mapper
; <-
;	xor	a
	ld	(SCCbnk0),a	; Select page 0 on bank 4000h~5FFFh if Rom mapper is SCC
	ld	(SCCbnk1),a	; Select page 0 on bank 6000h~7FFFh if Rom mapper is SCC
	ld	a,080h
	ld	(bc),a		; Write 080h at 6000h or Mode RAM for ASC8

	ld	a,010h
	ld	(07ffeh),a	; Mode RAM at bank 4000h-7FFDh for SCC mapper
	ld	a,(bc)		; Read value at 6000h

	xor	(hl)
	jr	z,ASC8FND	; Jump if Rom mapper is ASC8 type (maybe 8k type)

	ld	a,1		; it's not 8k type
ASC8FND:
	ld	(Page16K),a
	ld	a,(hl)		; Read value at 4000h
	cpl
	ld	(hl),a		; Write reversed value at 4000h
	cp	(hl)
	cpl
	ld	(hl),a
	jr	z,Sram_OK	; Jump if Mega-sram found
	xor	a		;          <- useless?
	ld	(07ffeh),a	; Mode ROM for SCC mapper <- useless?
	ld	(bc),a		; Mode ROM for ASC8 mapper <- useless?
	jp	Exit		; Jump if not Mega-sram

Sram_OK:
	push	af
	ld	a,(bc)		; Read value at 4000h
	cpl
	ld	(hl),a
	ld	a,(bc)
	cp	(hl)
	jr	z,ModeRomOK	; Jump if not Ram mode

	ld	a,1
	ld	(Page16K),a	; Mapper page size is 16KB

ModeRomOK:
	pop	af
	ld	(hl),a

	xor	a
	ld	(07ffeh),a	; Mode ROM for SCC mapper
	ld	(bc),a		; Mode ROM for ASC8 mapper
	ld	(ESEramPage),a
	inc	a
	ld	(ASCbnk1),a	; Select page 0 on bank 6000h~7FFFh if Rom mapper is ASC8
	ld	(SCCbnk1),a	; Select page 0 on bank 6000h~7FFFh if Rom mapper is SCC

	ld	a,(RAMAD1)
	ld	h,040h
	call	ENASLT		; Select Main-Ram slot on bank 4000h~7fffh

	ld	a,(Page16K)
	or	a
	jp	nz,Loop16k	; Jump if Mapper page size is 16KB
Loop8k:
	ld	c,027h
	ld	de,FCB
	ld	hl,02000h	; Number of records to read
	call	BDOS		; Read a block from file

	ld	a,h
	or	l
	ld	de,DoneMes
	jp	z,Exit

	ld	a,h
	cp	020h
	ld	de,FileErrMes
	jp	nz,Exit

	ld	a,(ESEramSlot)
	ld	h,040h
	call	ENASLT		; Select Mega-sram slot on bank 4000h~7fffh

	xor	a
	ld	(07ffeh),a	; Mode ROM for SCC mapper
	ld	(ASCbnk0),a	; Mode ROM for ASC8 mapper
	ld	a,(ESEramPage)
	ld	(SCCbnk0),a
	or	080h
	ld	(ASCbnk0),a
	ld	a,010h
	ld	(07ffeh),a	; Mode RAM at bank 4000h-7FFDh for SCC mapper

	ld	bc,02000h
	ld	de,04000h
	ld	hl,08000h
	ldir

	xor	a
	ld	(07ffeh),a	; Mode ROM for SCC mapper
	ld	(ASCbnk0),a	; Mode ROM for ASC8 mapper

	ld	a,(RAMAD1)
	ld	h,40h
	call	ENASLT		; Select Main-Ram slot on bank 4000h~7fffh

	ld	a,(ESEramPage)
	inc	a
	ld	(ESEramPage),a
	dec	a
	and	0fh
	cp	0ah
	jr	c,NotNumber	; Jump if alphabetic character
	add	a,7		; Add 'A'-'0'-10
NotNumber:
	add	a,030h		; Character '0'
	ld	e,a
	ld	c,2
	call	BDOS		; Print page number

	ld	a,(ESEramPage)
	and	0fh
	jp	nz,Loop8k

	ld	e,CR
	ld	c,2
	call	BDOS		; Move cursor to beging line

	ld	e,LF
	ld	c,2
	call	BDOS		; Move cursor to next line

	jp	Loop8k

Loop16k:
	ld	c,027h
	ld	de,FCB
	ld	hl,04000h	; Number of records to read
	call	BDOS		; Read a block from file

	ld	a,h
	or	l
	ld	de,DoneMes
	jp	z,Exit		; Jump if no byte read.

	ld	a,h
	cp	040h
	ld	de,FileErrMes
	jp	nz,Exit	; Jump if bytes read < 4000h.

	ld	bc,04000h
	ld	de,04000h
	ld	hl,08000h
	ldir			; Write a page to SRAM

	ld	hl,SCCbnk1
	ld	a,(ESEramPage)
	or	080h
	ld	e,a
	ld	a,(ESEramSlot)
	call	WRSLT		; Select a page in Mega-sram SCC on bank 8000h~bfffh

	ld	a,(ESEramSlot)
	ld	h,080h
	call	ENASLT		; Select Mega-sram slot on bank 8000h~bfffh

	ld	bc,04000h
	ld	de,08000h
	ld	hl,04000h
	ldir

	ld	a,(RAMAD2)
	ld	h,080h
	call	ENASLT		; Select Main-Ram on bank 8000h~bfffh

	ld	hl,SCCbnk1
	ld	e,1
	ld	a,(ESEramSlot)
	call	WRSLT		; Select page 1 in Mega-sram SCC on bank 8000h~bfffh

	ld	a,(ESEramPage)
	inc	a
	ld	(ESEramPage),a
	dec	a
	and	7
	add	a,030h
	ld	e,a
	ld	c,2
	call	BDOS		; Print page number

	ld	a,(ESEramPage)
	and	7
	jp	nz,Loop16k

	ld	e,CR
	ld	c,2
	call	BDOS		; Move cursor to beging line

	ld	e,LF
	ld	c,2
	call	BDOS		; Move cursor to next line

	jp	Loop16k

Exit:
	pop	af
	ld	c,9
	call	BDOS		; Print message before exit to DOS
	rst	0

GetNum:
	ld	de,0
GetL01:
	inc	hl
	ld	a,(hl)
	sub	030h		; sub	'0'
	ret	c
	cp	10
	jr	c,GetR01
	and	0dfh
	sub	7		; sub	'A'-'0'-10
	ret	c
	cp	16
	ccf
	ret	c
GetR01:
	sla	e
	rl	d
	sla	e
	rl	d
	sla	e
	rl	d
	sla	e
	rl	d
	add	a,e
	ld	e,a
	jr	GetL01

ESEramSlot:
	nop		; Mega-sram Slot
Page16K:
	nop
ESEramPage:
	nop

